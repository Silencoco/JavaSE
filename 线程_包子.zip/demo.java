package 案例.线程_包子;

public class demo {
    public static void main(String[] args) {
        BaoZi baoZi = new BaoZi();
        new BaoZiPu(baoZi).start();//匿名线程
        new ChiHuo(baoZi).start();
    }
}
