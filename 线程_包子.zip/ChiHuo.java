package 案例.线程_包子;

public class ChiHuo extends Thread{
    private BaoZi baoZi;

    public ChiHuo(BaoZi baoZi) {
        this.baoZi = baoZi;
    }

    @Override
    public void run() {
        //吃包子,使用同一个锁
        while (true){
            synchronized (baoZi){
                if (baoZi.flag==false){
                    try {
                        baoZi.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                //被唤醒之后执行的代码，吃包子
                System.out.println("吃货正在吃"+baoZi.pi+baoZi.xian+"包子");
                //吃货吃完
                baoZi.flag=false;
                baoZi.notify();
                System.out.println("吃完了，包子铺开始生产");
                System.out.println("===================");
            }
        }
    }
}
