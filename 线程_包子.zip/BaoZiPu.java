package 案例.线程_包子;

public class BaoZiPu extends Thread{
    /*
    包子铺和包子线程关系 通信（互斥）
    必须同时同步技术保证两个线程只有一个在执行
    锁对象必须保证唯一，可以使用包子对象作为锁对象
    包子铺类和吃货的类就需要吧包子对象最为参数传递进来
    1、需要在成员位置创建一个包子变量
    2、使用带参数的构造方法，为这个包子变量赋值
     */
    private BaoZi baoZi;

    public BaoZiPu(BaoZi baoZi) {
        this.baoZi = baoZi;
    }
    //生产包子(设置线程任务)
    @Override
    public void run() {
        int count = 0;
        while (true) {
            synchronized (baoZi) {
                if (baoZi.flag == true) {
                    //包子铺调用wait方法进入等待状态
                    try {
                        baoZi.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                //            baoZi.flag=false;
                if (count % 2 == 0) {
                    baoZi.pi = "薄皮";
                    baoZi.xian = "三鲜";
                } else {
                    baoZi.pi = "冰皮";
                    baoZi.xian = "牛肉";
                }
                count++;
                System.out.println("正在生产:" + baoZi.pi + baoZi.xian + "包子");
                //生产时间
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                //生产好了
                //修改状态为true
                baoZi.flag = true;
                //唤醒吃货线程
                baoZi.notify();
                System.out.println("包子铺已经生产好了：" + baoZi.pi + baoZi.xian + "包子，可以开始吃了");
            }
        }
    }
}
