package 案例.线程_包子;

public class BaoZi {
    String pi;
    String xian;
    boolean flag=false;//包子的状态
}
