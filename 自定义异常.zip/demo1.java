package 案例.自定义异常;

import java.util.Collections;
import java.util.HashSet;
import java.util.Scanner;

/*
要求：我们模拟注册操作，如果用户名已存在，则抛出异常并提示：亲，该用户名已经被注册。
 */
public class demo1 {
    public static void main(String[] args) throws registerException {
        System.out.println("请输入您的用户名");
        Scanner sc = new Scanner(System.in);
        String input = sc.next();
        repetition(input);
    }

    private static void repetition(String input){
        HashSet<String> list = new HashSet<>();
        Collections.addAll(list,"a","b","c","d");
        int num=0;
        for (String s:list
             ) {
            if (s.equals(input)){
                num++;
            }
        }
        if (num==1){
            try {
                throw new Exception("已经被注册了");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }else {
            System.out.println("恭喜！注册成功");
        }
    }
}
